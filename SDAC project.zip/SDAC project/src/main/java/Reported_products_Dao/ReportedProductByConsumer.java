package Reported_products_Dao;

import Pojo.ReportedProducts;
import Connection.GetConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReportedProductByConsumer {
    public List<ReportedProducts> getReportedProductsByConsumer(String consumerPortId) {
        List<ReportedProducts> reportedProductsList = new ArrayList<>();
        
        String query = "{ CALL GetReportedProductsByConsumer(?) }";

        try (Connection connection = GetConnection.getConnection();
             CallableStatement statement = connection.prepareCall(query)) {

            System.out.println("Executing stored procedure with consumerPortId: " + consumerPortId);
            statement.setString(1, consumerPortId);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                ReportedProducts reportedProduct = new ReportedProducts();
                reportedProduct.setReportId(resultSet.getString("Report_ID"));
                reportedProduct.setConsumerPortId(resultSet.getString("Consumer_Port_ID"));
                reportedProduct.setProductId(resultSet.getInt("Product_ID"));
                reportedProduct.setIssueType(resultSet.getString("Issue_Type"));
                reportedProduct.setSolution(resultSet.getString("Solution"));
                reportedProduct.setReportDate(resultSet.getTimestamp("Report_Date"));

                reportedProductsList.add(reportedProduct);
            }
        } catch (SQLException e) {
            System.out.println("Error in DAO: " + e.getMessage());
            e.printStackTrace();
        }

        return reportedProductsList;
    }
}
