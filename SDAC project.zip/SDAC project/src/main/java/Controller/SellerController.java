package Controller;

import Pojo.SellerPort;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

import Implementor.SellerImp;

public class SellerController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private SellerImp sellerService;

    public void init() {
        sellerService = new SellerImp(); // Initialize the SellerImp service class
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action != null) {
            switch (action) {
                case "register":
                    registerSeller(request, response);
                    break;
                case "login":
                    loginSeller(request, response);
                    break;
            }
        }
    }


    // Method to register a new seller
    private void registerSeller(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String portID = request.getParameter("portID");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        SellerPort seller = new SellerPort(portID, password, role);
        sellerService.registerSeller(seller);
        response.sendRedirect("login.jsp");
    }

    // Method to login a seller
    private void loginSeller(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String portID = request.getParameter("portID");
        String password = request.getParameter("password");

        SellerPort seller = new SellerPort(portID, password, null);
        
        // Check if the login was successful
        boolean loginSuccess = sellerService.loginSeller(seller);
        if (loginSuccess) {
            // Login successful, redirect to the seller dashboard
        	request.getSession().setAttribute("port_id", portID);
            response.sendRedirect("sellerDashboard.jsp");
        } else {
            // Login failed, redirect back to the login page with an error
            response.sendRedirect("login.jsp?error=invalid");
        }
    }


}
