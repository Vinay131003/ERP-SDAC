package Implementor;

import Operation.Seller;
import Pojo.SellerPort;
import Seller_Dao.LoginSellerDao;
import Seller_Dao.RegisterSellerDao;
import java.util.List;

public class SellerImp implements Seller {

    // DAO instances
    private RegisterSellerDao registerSellerDao = new RegisterSellerDao();
    private LoginSellerDao loginSellerDao = new LoginSellerDao();

    @Override
    public void registerSeller(SellerPort seller) {
        registerSellerDao.registerSeller(seller);
    }

    @Override
 // In SellerImp
    public boolean loginSeller(SellerPort seller) {
        return loginSellerDao.loginSeller(seller); // Assuming you have an instance of LoginSellerDao
    }
}
