package Consumer_Dao;

import Connection.GetConnection;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.SQLException;
import Pojo.ConsumerPort;

public class DeleteConsumerProfileDao {
    public void deleteConsumerProfile(ConsumerPort consumer) {
        String sql = "{CALL DeleteProfile(?)}";
        try (Connection conn = GetConnection.getConnection();
             CallableStatement stmt = conn.prepareCall(sql)) {
            stmt.setString(1, consumer.getPortID());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
